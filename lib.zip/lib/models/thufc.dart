class Thufc{
  final String name;
  final String sugars;
  final int strength;

  Thufc({this.name, this.sugars, this.strength});
}