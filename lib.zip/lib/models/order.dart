class Orders{
  final String id;
  final String customer;
  final String phone;
//  final String timeStart;
//  final String timeEnd;
//  final String note;
//  final DateTime dateOrder;
//  final DateTime datePlay;

  Orders({
    this.id,
    this.customer,
    this.phone,
//    this.timeStart,
//    this.timeEnd,
//    this.note,
//    this.dateOrder,
//    this.datePlay
  });
}