import 'package:appdemo/services/auth.dart';
import 'package:flutter/material.dart';

class Mess extends StatefulWidget {
  @override
  _MessState createState() => _MessState();
}

class _MessState extends State<Mess> {
  final AuthService _auth = AuthService();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.brown[50],
        appBar: AppBar(
          title: Text('Message page', style: TextStyle(color: Colors.yellow)),
          backgroundColor: Colors.green[400],
          elevation:  0.0,
          actions: <Widget>[

            FlatButton.icon(
              icon: Icon(Icons.person),
              label: Text('logout'),
              onPressed: () async {
                await _auth.signOut();
              },
            ),

            FlatButton.icon(
              icon: Icon(Icons.settings),
              label: Text(''),
//              onPressed: () => _showSettingPanel(),
            ),
          ],
        ),
        body: Center(
          child: Text('Chức năng đang được xây dựng, xin vui lòng quay lại sau!'),
        )


    );
  }
}
