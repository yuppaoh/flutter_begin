import 'package:appdemo/screens/home/thufc_title.dart';
import 'package:appdemo/services/auth.dart';
import 'package:appdemo/shared/constants.dart';
import 'package:appdemo/shared/input_time.dart';
import 'package:date_field/date_field.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:appdemo/services/database.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';

class Product extends StatefulWidget {

  @override
  _ProductState createState() => _ProductState();
}

class _ProductState extends State<Product> {
  final AuthService _auth = AuthService();
  DateTime selectedData;
  DateTime _dateTime = DateTime.now();



  @override
  Widget build(BuildContext context) {
    void _showSettingPanel() {
      showModalBottomSheet(context: context, builder: (context){
        return Container(
          padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 60.0),
          child: Text('bottom sheet'),
        );
      });
    }

    return Scaffold(
        backgroundColor: Colors.brown[50],
//        resizeToAvoidBottomPadding: false,
        appBar: AppBar(
          title: Text('Đặt sân', style: TextStyle(color: Colors.yellow)),
          backgroundColor: Colors.green[400],
          elevation:  0.0,
          actions: <Widget>[
            FlatButton.icon(
              icon: Icon(Icons.person),
              label: Text('logout'),
              onPressed: () async {
                await _auth.signOut();
              },
            ),
            FlatButton.icon(
              icon: Icon(Icons.settings),
              label: Text(''),
              onPressed: () => _showSettingPanel(),
            ),
          ],
        ),
        body: ListView(
            padding: EdgeInsets.symmetric(vertical: 0.0, horizontal: 16.0),
            children: <Widget>[
              SizedBox(height: 20.0),
              Text(
                'Hôm nay: ${_dateTime.day}/${_dateTime.month}/${_dateTime.year}',
                style: TextStyle(
                  fontStyle: FontStyle.italic, color: Colors.blue[800]),
              ),
              SizedBox(height: 20.0),
              TextFormField(
                  validator: (val) => val.isEmpty ? 'Xin nhập tên' : null,
                  decoration: textInputDecoration.copyWith(hintText: 'Tên người đặt '),
                  onChanged: (val) {}
              ),
              SizedBox(height: 20.0),
              TextFormField(
                  validator: (val) => val.isEmpty ? 'Xin nhập số điện thoại' : null,
                  decoration: textInputDecoration.copyWith(hintText: 'Số điện thoại'),
                  onChanged: (val) {}
              ),
              SizedBox(height: 20.0),
              DateField(
                onDateSelected: (DateTime value) {
                  setState(() {
                    selectedData = value;
                  });
                },
                decoration: InputDecoration(
                  border: OutlineInputBorder()
                ),
                label: 'Chọn ngày đá',
                //dateFormat: DateFormat.yMd(),
                dateFormat: DateFormat("dd/MM/yyyy"),
                selectedDate: selectedData,
              ),
              SizedBox(height: 20.0),
              Row(

                  children: <Widget>[
                    Text('Từ giờ: '),
                    inputTime(),
                    SizedBox(width: 40.0),
                    Text('Đến giờ: '),
                    inputTime(),
                  ]
              ),

//              SizedBox(height: 20.0),
//              TextFormField(
//                  validator: (val) => val.isEmpty ? 'Nhập giờ' : null,
//                  decoration: textInputDecoration.copyWith(hintText: 'Từ giờ'),
//                  onChanged: (val) {}
//              ),
//
//              SizedBox(height: 20.0),
//              TextFormField(
//                  validator: (val) => val.isEmpty ? 'Nhập giờ' : null,
//                  decoration: textInputDecoration.copyWith(hintText: 'Đến giờ'),
//                  onChanged: (val) {}
//              ),
              SizedBox(height: 20.0),
              RaisedButton(
                onPressed: () {
                  showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: Text('Xin cảm ơn bạn đã sử dụng dịch vụ!'),
                      )
                  );
                },
                padding: const EdgeInsets.all(15.0),
                color: Colors.green,
                child: const Text(
                  'Đặt sân',
                  style: TextStyle(color: Colors.yellow, fontSize: 18.0),
                ),
              ),
            ]
        ),

    );
  }
}


