import 'package:appdemo/models/thufc.dart';
import 'package:appdemo/screens/home/thufc_title.dart';
import 'package:appdemo/models/order.dart';
import 'package:appdemo/screens/layouts/thufc_title_layout.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class ThufcListLayout extends StatefulWidget {
  @override
  _ThufcListLayoutState createState() => _ThufcListLayoutState();
}

class _ThufcListLayoutState extends State<ThufcListLayout> {
  @override
  Widget build(BuildContext context) {
    final thufcs = Provider.of<List<Thufc>>(context);
    //final orders = Provider.of<List<Orders>>(context);

    return Scaffold(
      backgroundColor: Colors.brown[50],
//        resizeToAvoidBottomPadding: false,
      appBar: AppBar(
        title: Text('Index page', style: TextStyle(color: Colors.yellow)),
        backgroundColor: Colors.green[400],
        elevation:  0.0,
        actions: <Widget>[
          /*
            FlatButton.icon(
              icon: Icon(Icons.person),
              label: Text('logout'),
              onPressed: () async {
                await _auth.signOut();
              },
            ),
        */
          FlatButton.icon(
            icon: Icon(Icons.settings),
            label: Text(''),
//            onPressed: () => _showSettingPanel(),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: thufcs.length,
        itemBuilder: (context, index){
          return ThufcTitle(thufc: thufcs[index]);
          //return ThuFcTitleLayout(order: orders[index]);
        },
      ),
    );

    return Container();
  }
}
