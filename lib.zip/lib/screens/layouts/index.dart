import 'package:appdemo/models/thufc.dart';
import 'package:appdemo/screens/home/home.dart';
import 'package:appdemo/screens/home/thufc_list.dart';
import 'package:appdemo/screens/layouts/order.dart';
import 'package:appdemo/screens/layouts/orders_list.dart';
import 'package:appdemo/screens/layouts/product.dart';
import 'package:appdemo/screens/layouts/thufc_list_layout.dart';
import 'package:appdemo/services/database.dart';
import 'package:appdemo/services/auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'history.dart';
import 'lichsan.dart';
import 'message.dart';
import 'profile.dart';

class Index extends StatefulWidget {

  @override
  _IndexState createState() => _IndexState();
}

class _IndexState extends State<Index> {
  final AuthService _auth = AuthService();
  int _currentIndex = 0;
  final List<Widget> _children = [
    //ThufcListLayout(),
    //Home(),
    OrderList(),
    Order(),
    //Product(),

    LichSan(),
//    Mess(),
    History(),
    Profile(),
  ];

  void onTapBar(int number){
    setState(() {
      _currentIndex = number;
//      print(_currentIndex.toString());
    });
  }

  @override
  Widget build(BuildContext context) {
    void _showSettingPanel() {
      showModalBottomSheet(context: context, builder: (context){
        return Container(
          padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 60.0),
          child: Text('bottom sheet'),
        );
      });
    }

    return StreamProvider<List<Thufc>>.value(
      value: DatabaseService().thufcs,
      child: Scaffold(
          backgroundColor: Colors.brown[50],
//        resizeToAvoidBottomPadding: false,
          body: _children[_currentIndex],

          bottomNavigationBar: BottomNavigationBar(
            currentIndex: _currentIndex,
            onTap: onTapBar,
            backgroundColor: Colors.white70,
            type: BottomNavigationBarType.fixed,
            items: [
              BottomNavigationBarItem(
                  icon: Icon(Icons.home),
                  title: Text('Home'),
                  backgroundColor: Colors.blue
              ),
              BottomNavigationBarItem(
                  icon: Icon(Icons.shop),
                  title: Text('Đặt sân'),
//                  backgroundColor: Colors.red
              ),
              BottomNavigationBarItem(
                  icon: Icon(Icons.message),
                  title: Text('Lịch đá'),
                  backgroundColor: Colors.green
              ),
              BottomNavigationBarItem(
                  icon: Icon(Icons.history),
                  title: Text('History'),
//                  backgroundColor: Colors.yellow
              ),
              BottomNavigationBarItem(
                  icon: Icon(Icons.person),
                  title: Text('Profile'),
//                  backgroundColor: Colors.lightGreenAccent
              ),
            ],
          )
      ),
    );
  }
}


