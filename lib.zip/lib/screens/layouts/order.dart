import 'package:appdemo/screens/home/thufc_title.dart';
import 'package:appdemo/services/auth.dart';
import 'package:appdemo/shared/constants.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:date_field/date_field.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:dropdown_formfield/dropdown_formfield.dart';

import 'index.dart';

class Order extends StatefulWidget {
  @override
  _OrderState createState() => _OrderState();
}

class _OrderState extends State<Order> {
  final AuthService _auth = AuthService();
  DateTime selectedData;
  DateTime _dateTime = DateTime.now();

  String id, customer, phone, timeStart, timeEnd; //, note
  DateTime dateOrder, datePlay;
  String orderId, dateTimePlayID;
  String strNow = "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}";

  String _myActivity;
  String _myActivityResult;
  final formKeyStart = new GlobalKey<FormState>();
  final formKeyEnd = new GlobalKey<FormState>();

  getID(id) {
    this.id = id;
  }

  getCustomer(customer) {
    this.customer = customer;
  }

  getPhoneNo(phone) {
    this.phone = phone;
  }

  getTimeStart(time) {
    this.timeStart = time;
  }

  getTimeEnd(time) {
    this.timeEnd = time;
  }

//  getNote(str) {
//    this.note = str;
//  }
//

  getDateOrder(DateTime date) {
    this.dateOrder = date;
  }
  getDatePlay(DateTime date) {
    this.datePlay = date;
  }

  createOrder() {
    DocumentReference documentReference = Firestore.instance.collection("orders").document(orderId);
    // create Map
    Map<String, dynamic> orders = {
      "customer": customer,
      "dateOrder": _dateTime.toString(),
      "datePlay": datePlay.toString(),
      "dateTimePlayID": dateTimePlayID,
      "note": null,
      "orderID": orderId,
      "orderStatus": 'Pending',
      "phone": phone,
      "sanNo": null,
      "timeEnd": timeEnd,
      "timeStart": timeStart,
      "userManagement": null,
      "userOrder": null,
    };

    documentReference.setData(orders).whenComplete(() {
      print("Order created");
    });
  }

  Future<void> _showMyDialog() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('AlertDialog Title'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('Dat san khong thanh cong.'),
                Text('Chua co thong tin!'),
              ],
            ),
          ),
          actions: <Widget>[
            FlatButton(
              child: Text('Quay lai'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    void _showSettingPanel() {
      showModalBottomSheet(
          context: context,
          builder: (context) {
            return Container(
              padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 60.0),
              child: Text('bottom sheet'),
            );
          });
    }

    return Scaffold(
      backgroundColor: Colors.brown[50],
//        resizeToAvoidBottomPadding: false,
      appBar: AppBar(
        title: Text('Đặt sân Football', style: TextStyle(color: Colors.yellow)),
        backgroundColor: Colors.green[400],
        elevation: 0.0,
        actions: <Widget>[
          FlatButton.icon(
            icon: Icon(Icons.person),
            label: Text('logout'),
            onPressed: () async {
              await _auth.signOut();
            },
          ),
          FlatButton.icon(
            icon: Icon(Icons.settings),
            label: Text(''),
            onPressed: () => _showSettingPanel(),
          ),
        ],
      ),
      body: ListView(
          padding: EdgeInsets.symmetric(vertical: 0.0, horizontal: 16.0),
          children: <Widget>[
            SizedBox(height: 20.0),
            Text(
              'Hôm nay: ${DateFormat("dd/MM/yyyy").format(DateTime.now()).toString()}',
              style: TextStyle(
                  fontStyle: FontStyle.italic, color: Colors.blue[800]),
            ),
            SizedBox(height: 20.0),
            Text(
              'OrderId: $orderId',
              style: TextStyle(
                  fontStyle: FontStyle.italic, color: Colors.blue[800]),
            ),
            SizedBox(height: 20.0),
            Text(
              'dateTimePlayID: $dateTimePlayID',
              style: TextStyle(
                  fontStyle: FontStyle.italic, color: Colors.blue[800]),
            ),
            SizedBox(height: 20.0),
            DateField(
              decoration: InputDecoration(border: OutlineInputBorder()),
              label: 'Chọn ngày đá',
              dateFormat: DateFormat("dd/MM/yyyy"),
              selectedDate: selectedData,
              onDateSelected: (DateTime value) {
                setState(() {
                  selectedData = value;
                  getDatePlay(value);
                  orderId = '${DateFormat("yyyyMMdd").format(DateTime.now()).toString()}${_dateTime.hour.toString().padLeft(2,'0')}${_dateTime.minute.toString().padLeft(2,'0')}${_dateTime.second.toString().padLeft(2,'0')}${_dateTime.millisecond.toString().padLeft(3,'0')}${_dateTime.microsecond.toString().padLeft(3,'0')}';
                });
              },
            ),
            SizedBox(height: 20.0),
            Row(
                children: <Widget>[
                  //Tu gio
                  Expanded(
                    child: Form(
                      key: formKeyStart,
                      child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(left: 0.0, top: 0.0, right: 0.0, bottom: 0.0),
                        child: DropDownFormField(
                          titleText: 'Từ giờ',
                          hintText: 'Nhấn để chọn',
                          value: timeStart,
                          onChanged: (value) {
                            setState(() {
                              getTimeStart(value);
                              dateTimePlayID = '${DateFormat("yyyyMMdd").format(datePlay).toString()}${timeStart.toString()}';
                              //print('Time_start: $time_start');
                            });
                          },
                          dataSource: [
                            {
                              "display": "00:00",
                              "value": "00:00",
                            },
                            {
                              "display": "00:30",
                              "value": "00:30",
                            },
                            {
                              "display": "01:00",
                              "value": "01:00",
                            },
                            {
                              "display": "01:30",
                              "value": "01:30",
                            },
                            {
                              "display": "02:00",
                              "value": "02:00",
                            },
                            {
                              "display": "02:30",
                              "value": "02:30",
                            },
                            {
                              "display": "03:00",
                              "value": "03:00",
                            },
                            {
                              "display": "03:30",
                              "value": "03:30",
                            },
                            {
                              "display": "04:00",
                              "value": "04:00",
                            },
                            {
                              "display": "04:30",
                              "value": "04:30",
                            },
                            {
                              "display": "05:00",
                              "value": "05:00",
                            },
                            {
                              "display": "05:30",
                              "value": "05:30",
                            },
                            {
                              "display": "06:00",
                              "value": "06:00",
                            },
                            {
                              "display": "06:30",
                              "value": "06:30",
                            },
                            {
                              "display": "07:00",
                              "value": "07:00",
                            },
                            {
                              "display": "07:30",
                              "value": "07:30",
                            },
                            {
                              "display": "08:00",
                              "value": "08:00",
                            },
                            {
                              "display": "08:30",
                              "value": "08:30",
                            },
                            {
                              "display": "09:00",
                              "value": "09:00",
                            },
                            {
                              "display": "09:30",
                              "value": "09:30",
                            },
                            {
                              "display": "10:00",
                              "value": "10:00",
                            },
                            {
                              "display": "10:30",
                              "value": "10:30",
                            },
                            {
                              "display": "11:00",
                              "value": "11:00",
                            },
                            {
                              "display": "11:30",
                              "value": "11:30",
                            },
                            {
                              "display": "12:00",
                              "value": "12:00",
                            },
                            {
                              "display": "12:30",
                              "value": "12:30",
                            },
                            {
                              "display": "13:00",
                              "value": "13:00",
                            },
                            {
                              "display": "13:30",
                              "value": "13:30",
                            },
                            {
                              "display": "14:00",
                              "value": "14:00",
                            },
                            {
                              "display": "14:30",
                              "value": "14:30",
                            },
                            {
                              "display": "15:00",
                              "value": "15:00",
                            },
                            {
                              "display": "15:30",
                              "value": "15:30",
                            },
                            {
                              "display": "16:00",
                              "value": "16:00",
                            },
                            {
                              "display": "16:30",
                              "value": "16:30",
                            },
                            {
                              "display": "17:00",
                              "value": "17:00",
                            },
                            {
                              "display": "17:30",
                              "value": "17:30",
                            },
                            {
                              "display": "18:00",
                              "value": "18:00",
                            },
                            {
                              "display": "18:30",
                              "value": "18:30",
                            },
                            {
                              "display": "19:00",
                              "value": "19:00",
                            },
                            {
                              "display": "19:30",
                              "value": "19:30",
                            },
                            {
                              "display": "20:00",
                              "value": "20:00",
                            },
                            {
                              "display": "20:30",
                              "value": "20:30",
                            },
                            {
                              "display": "21:00",
                              "value": "21:00",
                            },
                            {
                              "display": "21:30",
                              "value": "21:30",
                            },
                            {
                              "display": "22:00",
                              "value": "22:00",
                            },
                            {
                              "display": "22:30",
                              "value": "22:30",
                            },
                            {
                              "display": "23:00",
                              "value": "23:00",
                            },
                            {
                              "display": "23:30",
                              "value": "23:30",
                            },
                          ],
                          textField: 'display',
                          valueField: 'value',
                        )
                      ),
                    )
                  ),
                  SizedBox(width: 15.0),
                  //Den gio
                  Expanded(
                      child: Form(
                        key: formKeyEnd,
                        child: Container(
                          color: Colors.white,
                          padding: EdgeInsets.only(left: 0.0, top: 0.0, right: 0.0, bottom: 0.0),
                          child: DropDownFormField(
                            titleText: 'Đến giờ',
                            hintText: 'Nhấn để chọn',
                            value: timeEnd,
                            onChanged: (value) {
                              setState(() {
                                getTimeEnd(value);
                                //print('Time_end: $time_end');
                              });
                            },
                            dataSource: [
                              {
                                "display": "00:00",
                                "value": "00:00",
                              },
                              {
                                "display": "00:30",
                                "value": "00:30",
                              },
                              {
                                "display": "01:00",
                                "value": "01:00",
                              },
                              {
                                "display": "01:30",
                                "value": "01:30",
                              },
                              {
                                "display": "02:00",
                                "value": "02:00",
                              },
                              {
                                "display": "02:30",
                                "value": "02:30",
                              },
                              {
                                "display": "03:00",
                                "value": "03:00",
                              },
                              {
                                "display": "03:30",
                                "value": "03:30",
                              },
                              {
                                "display": "04:00",
                                "value": "04:00",
                              },
                              {
                                "display": "04:30",
                                "value": "04:30",
                              },
                              {
                                "display": "05:00",
                                "value": "05:00",
                              },
                              {
                                "display": "05:30",
                                "value": "05:30",
                              },
                              {
                                "display": "06:00",
                                "value": "06:00",
                              },
                              {
                                "display": "06:30",
                                "value": "06:30",
                              },
                              {
                                "display": "07:00",
                                "value": "07:00",
                              },
                              {
                                "display": "07:30",
                                "value": "07:30",
                              },
                              {
                                "display": "08:00",
                                "value": "08:00",
                              },
                              {
                                "display": "08:30",
                                "value": "08:30",
                              },
                              {
                                "display": "09:00",
                                "value": "09:00",
                              },
                              {
                                "display": "09:30",
                                "value": "09:30",
                              },
                              {
                                "display": "10:00",
                                "value": "10:00",
                              },
                              {
                                "display": "10:30",
                                "value": "10:30",
                              },
                              {
                                "display": "11:00",
                                "value": "11:00",
                              },
                              {
                                "display": "11:30",
                                "value": "11:30",
                              },
                              {
                                "display": "12:00",
                                "value": "12:00",
                              },
                              {
                                "display": "12:30",
                                "value": "12:30",
                              },
                              {
                                "display": "13:00",
                                "value": "13:00",
                              },
                              {
                                "display": "13:30",
                                "value": "13:30",
                              },
                              {
                                "display": "14:00",
                                "value": "14:00",
                              },
                              {
                                "display": "14:30",
                                "value": "14:30",
                              },
                              {
                                "display": "15:00",
                                "value": "15:00",
                              },
                              {
                                "display": "15:30",
                                "value": "15:30",
                              },
                              {
                                "display": "16:00",
                                "value": "16:00",
                              },
                              {
                                "display": "16:30",
                                "value": "16:30",
                              },
                              {
                                "display": "17:00",
                                "value": "17:00",
                              },
                              {
                                "display": "17:30",
                                "value": "17:30",
                              },
                              {
                                "display": "18:00",
                                "value": "18:00",
                              },
                              {
                                "display": "18:30",
                                "value": "18:30",
                              },
                              {
                                "display": "19:00",
                                "value": "19:00",
                              },
                              {
                                "display": "19:30",
                                "value": "19:30",
                              },
                              {
                                "display": "20:00",
                                "value": "20:00",
                              },
                              {
                                "display": "20:30",
                                "value": "20:30",
                              },
                              {
                                "display": "21:00",
                                "value": "21:00",
                              },
                              {
                                "display": "21:30",
                                "value": "21:30",
                              },
                              {
                                "display": "22:00",
                                "value": "22:00",
                              },
                              {
                                "display": "22:30",
                                "value": "22:30",
                              },
                              {
                                "display": "23:00",
                                "value": "23:00",
                              },
                              {
                                "display": "23:30",
                                "value": "23:30",
                              },
                            ],
                            textField: 'display',
                            valueField: 'value',
                          )
                        ),
                      )
                  ),
                ]),
            SizedBox(height: 20.0),
            TextFormField(
                validator: (val) => val.isEmpty ? 'Xin nhập tên' : null,
                decoration:
                textInputDecoration.copyWith(hintText: 'Tên người đặt '),
                onChanged: (String name) {
                  getCustomer(name);
                }),
            SizedBox(height: 20.0),
            TextFormField(
                validator: (val) =>
                val.isEmpty ? 'Xin nhập số điện thoại' : null,
                decoration:
                textInputDecoration.copyWith(hintText: 'Số điện thoại'),
                onChanged: (String phone) {
                  getPhoneNo(phone);
                }),
            SizedBox(height: 25.0),
            RaisedButton(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40.0),
                  side: BorderSide(color: Colors.green)
              ),
              onPressed: () {
                if(orderId != null){
                  getDateOrder(_dateTime);
                  createOrder();
//                  showDialog(
//                      context: context,
//                      builder: (_) => AlertDialog(
//                        title: Text('Xin cảm ơn bạn đã sử dụng dịch vụ!'),
//                      ));
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (BuildContext context) => Index()
                    )
                  );
                }else{
                  _showMyDialog();
                }
              },
              padding: const EdgeInsets.all(15.0),
              color: Colors.green,
              child: const Text(
                'Đặt sân',
                style: TextStyle(color: Colors.yellow, fontSize: 18.0),
              ),
            ),
          ]),
    );
  }
}
