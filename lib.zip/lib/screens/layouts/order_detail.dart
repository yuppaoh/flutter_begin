import 'package:appdemo/services/auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';

class OrderDetail extends StatelessWidget {
  final AuthService _auth = AuthService();

  String customerName, note, orderId, orderStatus, phoneNo, sanNo;
  String timeEnd, timeStart, userManagement, userOrder;
  String  dateOrder, datePlay, dateTimePlayID;

  OrderDetail({this.customerName, this.note, this.orderId, this.orderStatus, this.phoneNo, this.sanNo,
    this.timeEnd, this.timeStart, this.userManagement, this.userOrder, this.dateOrder, this.datePlay, this.dateTimePlayID
  });
  getCustomer(name) {
    this.customerName = name;
  }
  getPhoneNo(phone) {
    this.phoneNo = phone;
  }
  getSan(san) {
    this.sanNo = san;
  }

  updateSan(String id, String san) {
    DocumentReference documentReference = Firestore.instance.collection(
        "orders").document(orderId);
    Map<String, dynamic> orders = {
      "customer": customerName,
      "dateOrder": dateOrder,
      "datePlay": datePlay,
      "dateTimePlayID": dateTimePlayID,
      "note": note,
      "orderID": orderId,
      "orderStatus": orderStatus,
      "phone": phoneNo,
      "sanNo": san,
      "timeEnd": timeEnd,
      "timeStart": timeStart,
      "userManagement": userManagement,
      "userOrder": userOrder,
    };
    documentReference.setData(orders).whenComplete(() {
    });
  }

  deleteOrder(){
    DocumentReference documentReference = Firestore.instance.collection(
        "orders").document(orderId);
    documentReference.delete().whenComplete(() {
      print('Deleted Order: $orderId');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.brown[50],
      appBar: AppBar(
        title: Text('', style: TextStyle(color: Colors.yellow)),
        backgroundColor: Colors.green[400],
        elevation:  0.0,
        actions: <Widget>[
          FlatButton.icon(
            icon: Icon(Icons.person),
            label: Text('logout'),
            onPressed: () async {
              await _auth.signOut();
            },
          ),
        ],
      ),

      body: ListView(
        padding: EdgeInsets.symmetric(vertical: 0.0, horizontal: 8.0),
        children: <Widget>[
          SizedBox(height: 20.0),
          Container(
            padding: EdgeInsets.symmetric(vertical: 0.0, horizontal: 16.0),
            height: 50.0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  'THÔNG TIN ĐẶT SÂN',
                  style: TextStyle(
                      fontStyle: FontStyle.normal,
                      fontWeight: FontWeight.bold,
                      fontSize: 22.0,
                      color: Colors.blue[800]
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 20.0),
          Container(
            padding: EdgeInsets.symmetric(vertical: 0.0, horizontal: 16.0),
            height: 50.0,
            color: Colors.white,
            child: Row(
              children: <Widget>[
                Text(
                  'OrderId: $orderId',
                  style: TextStyle(
                      fontStyle: FontStyle.normal, color: Colors.grey[500]),
                ),
              ],
            ),
          ),

          SizedBox(height: 8.0),
          Container(
            padding: EdgeInsets.symmetric(vertical: 0.0, horizontal: 16.0),
            height: 50.0,
            color: Colors.white,
            child: Row(
              children: <Widget>[
                Text(
                  'Khách hàng:',
                  style: TextStyle(
                      fontStyle: FontStyle.normal,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(width: 6.0),
                Text(
                  '$customerName',
                  style: TextStyle(
                      fontStyle: FontStyle.normal,
                      fontSize: 20.0,
                      color: Colors.blue[900]),
                ),
                IconButton(
                  icon: Icon(
                    Icons.edit,
                    color: Colors.blue,
                  ),
                  onPressed: () {
                  },
                ),
              ],
            )
          ),
          SizedBox(height: 8.0),
          Container(
            padding: EdgeInsets.symmetric(vertical: 0.0, horizontal: 16.0),
            height: 50.0,
            color: Colors.white,
            child: Row(
              children: <Widget>[
                Text(
                  'Điện thoại:',
                  style: TextStyle(
                      fontStyle: FontStyle.normal,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(width: 6.0),
                Text(
                  '$phoneNo',
                  style: TextStyle(
                      fontStyle: FontStyle.normal,
                      fontSize: 20.0,
                      color: Colors.blue[900]),
                ),
                IconButton(
                  icon: Icon(
                    Icons.edit,
                    color: Colors.blue,
                  ),
                  onPressed: () {
                  },
                ),
              ],
            ),
          ),
          SizedBox(height: 8.0),
          Padding(
            padding: const EdgeInsets.all(0.0),
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 18.0, horizontal: 16.0),
              color: Colors.white70,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                      'Chọn sân đá',
                      style: TextStyle(
                          fontStyle: FontStyle.normal,
                          fontWeight: FontWeight.bold,
                          fontSize: 18.0,
                          color: Colors.deepOrange[900],
                      ),
                    ),
                  SizedBox(height: 18.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      RaisedButton(
                        color: Colors.lightGreen,
                        textColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18.0),
                            side: BorderSide(color: Colors.lightGreen)
                        ),
                        child: Text("Sân 1".toUpperCase(),
                            style: TextStyle(fontSize: 14)
                        ),
                        onPressed: () {
                          updateSan(orderId, '1');
                          Navigator.of(context).pop();
                        },
                      ),
//                      SizedBox(width: 8.0),
                      RaisedButton(
                        color: Colors.lightGreen,
                        textColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18.0),
                            side: BorderSide(color: Colors.lightGreen)
                        ),
                        onPressed: () {
                          updateSan(orderId, '2');
                          Navigator.of(context).pop();
                        },
                        child: Text("Sân 2".toUpperCase(),
                            style: TextStyle(fontSize: 14)),
                      ),
//                      SizedBox(width: 8),
                      RaisedButton(
                        color: Colors.lightGreen,
                        textColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18.0),
                            side: BorderSide(color: Colors.lightGreen)
                        ),
                        onPressed: () {
                          updateSan(orderId, '3');
                          Navigator.of(context).pop();
                        },
                        child: Text("Sân 3".toUpperCase(),
                            style: TextStyle(fontSize: 14)),
                      ),
                      RaisedButton(
                        color: Colors.red,
                        textColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18.0),
                            side: BorderSide(color: Colors.red)
                        ),
                        onPressed: () {
                          deleteOrder();
                          Navigator.of(context).pop();
                        },

                        child: Text("Xóa".toUpperCase(),
                          style: TextStyle(fontSize: 14)),
                      ),

                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
        ),
      );
  }
}
