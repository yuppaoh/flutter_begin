import 'package:flutter/material.dart';
import 'package:appdemo/models/order.dart';

class ThuFcTitleLayout extends StatelessWidget {
  final Orders order;
  ThuFcTitleLayout({this.order});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 8.0),
      child: Card(
        margin: EdgeInsets.fromLTRB(16.0, 6.0, 16.0, 0.0),
        child: ListTile(
          leading: CircleAvatar(
            radius: 25.0,
            backgroundColor: Colors.brown[100],
          ),
          title: Text(order.customer),
          subtitle: Text('Khach: ${order.customer}'),
        ),
      ),
    );
  }
}
