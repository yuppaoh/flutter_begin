import 'package:appdemo/models/thufc.dart';
import 'package:appdemo/screens/home/thufc_list.dart';
import 'package:appdemo/screens/layouts/order_detail.dart';
import 'package:appdemo/services/auth.dart';
import 'package:appdemo/services/database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class LichSan extends StatefulWidget {
  @override
  _LichSanState createState() => _LichSanState();
}

class _LichSanState extends State<LichSan> {
  TabController _tabController;
  final AuthService _auth = AuthService();

  String phone;
  readData() {
    DocumentReference documentReference =
    Firestore.instance.collection("orders")
        .document(phone);

    documentReference.get().then((datasnapshot) {
      print(datasnapshot.data["customer"]);
      print(datasnapshot.data["phone"]);
    });
  }

/*
  List<Widget> containers = [
    Container(
      color: Colors.grey,
    ),
    Container(
      color: Colors.white70,
    ),
    Container(
      color: Colors.blueGrey,
    ),
  ];
  */

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
//          backgroundColor: Colors.brown[50],
          appBar: AppBar(
            title: Text('Lịch sân',
                style: TextStyle(color: Colors.yellow)
            ),
            backgroundColor: Colors.green[400],
            elevation:  0.0,
            actions: <Widget>[

              FlatButton.icon(
                icon: Icon(Icons.person),
                label: Text('logout'),
                onPressed: () async {
                  await _auth.signOut();
                },
              ),

//              FlatButton.icon(
//                icon: Icon(Icons.settings),
//                label: Text(''),
//              //onPressed: () => _showSettingPanel(),
//              ),
            ],

            bottom: TabBar(
              //controller: _tabController,
              labelColor: Colors.blue[800],
              unselectedLabelColor: Colors.white,
              indicator: BoxDecoration(
                borderRadius: BorderRadius.only(topLeft: Radius.circular(15), topRight: Radius.circular(15)),
                color: Colors.brown[50],
              ),

              tabs: <Widget>[
                Tab(
                  child: Text('Sân 1',
                      style: TextStyle(fontFamily: '', fontSize: 18.0)),
                ),
                Tab(
                  child: Text('Sân 2',
                      style: TextStyle(fontFamily: '', fontSize: 18.0)),
                ),
                Tab(
                    child: Text('Sân 3',
                        style: TextStyle(fontFamily: '', fontSize: 18.0)),
                ),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              Container(
                color: Colors.brown[50],
                child: tab1(context),
              ),
              Container(
                color: Colors.brown[50],
                child: tab2(context),
              ),
              Container(
                color: Colors.brown[50],
                  child: tab3(context),
              ),
            ],
          )
      ),
    );
  }

  // =============================================
  Widget tab1 (BuildContext context){
    return StreamBuilder(
        stream: Firestore.instance.collection("orders")
            .where('sanNo', isEqualTo: '1')
            .where('orderStatus', isEqualTo: 'Pending')
            .orderBy("dateTimePlayID")
            //.orderBy("timeStart")
            .snapshots(),
        builder: (context, snapshot) {
          if(snapshot.hasData) {
            return ListView.builder(
                itemCount: snapshot.data.documents.length,
                itemBuilder: (context, index){
                  DocumentSnapshot documentSnapshot = snapshot.data.documents[index];
                  return Padding(
                    padding: EdgeInsets.only(top: 8.0),
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => OrderDetail(
                              customerName: '${documentSnapshot["customer"]}',
                              dateOrder: '${documentSnapshot["dateOrder"]}',
                              datePlay: '${documentSnapshot["datePlay"]}',
                              dateTimePlayID: '${documentSnapshot["dateTimePlayID"]}',
                              note: '${documentSnapshot["note"]}',
                              orderId: '${documentSnapshot["orderID"]}',
                              orderStatus: '${documentSnapshot["orderStatus"]}',
                              phoneNo: '${documentSnapshot["phone"]}',
                              sanNo: '${documentSnapshot["sanNo"]}',
                              timeEnd: '${documentSnapshot["timeEnd"]}',
                              timeStart: '${documentSnapshot["timeStart"]}',
                              userManagement: '${documentSnapshot["userManagement"]}',
                              userOrder: '${documentSnapshot["userOrder"]}',
                            )));
                      },
                      child: Card(
                        margin: EdgeInsets.fromLTRB(16.0, 6.0, 16.0, 0.0),
                        child: ListTile(
                          isThreeLine: true,
                          //leading: Icon(Icons.info),
                          leading: CircleAvatar(
                            radius: 25.0,
                            backgroundColor: Colors.brown[100],
                          ),
                          title: Text('${documentSnapshot["timeStart"]} - ${documentSnapshot["timeEnd"]} (${DateFormat("dd/MM/yyyy").format(DateTime.parse(documentSnapshot["datePlay"]))})',
                            style: TextStyle(color: Colors.red[900], fontSize: 16.0),),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox(height: 8.0),
                              Text('dateTimePlayID: (${documentSnapshot["dateTimePlayID"]})',
                                style: TextStyle(color: Colors.black, fontSize: 12.0),
                              ),
                              Text('${documentSnapshot["customer"]}',
                                style: TextStyle(color: Colors.blue[900], fontSize: 18.0),
                              ),
                              SizedBox(height: 8.0),
                              Text('Điện thoại: ${documentSnapshot["phone"]}',
                                style: TextStyle(color: Colors.blue[900], fontSize: 16.0),
                              ),
                              SizedBox(height: 8.0),
                              Row(
                                children: <Widget>[
                                  Text('Đá sân ${documentSnapshot["sanNo"]}  -',
                                    style: TextStyle(color: Colors.blue[900], fontSize: 16.0),
                                  ),
                                  SizedBox(width: 8.0),
                                  Text('${documentSnapshot["orderStatus"]}',
                                    style: TextStyle(color: Colors.blue, fontSize: 16.0),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          //subtitle: Text(documentSnapshot["customer"]),
                          //trailing: ,
                        ),
                      ),
                    ),
                  );
                }
            );
          }else{
            return Align(

              alignment: FractionalOffset.center,
              child: Text("Loading..."),
            );
          }
        }
    );
  }

  // =============================================
  Widget tab2 (BuildContext context){
    return StreamBuilder(
        stream: Firestore.instance.collection("orders")
            .where('sanNo', isEqualTo: '2')
            .where('orderStatus', isEqualTo: 'Pending')
            .orderBy("dateTimePlayID")
            //.orderBy("timeStart")
            .snapshots(),
        builder: (context, snapshot) {
          if(snapshot.hasData) {
            return ListView.builder(
                itemCount: snapshot.data.documents.length,
                itemBuilder: (context, index){
                  DocumentSnapshot documentSnapshot = snapshot.data.documents[index];
                  return Padding(
                    padding: EdgeInsets.only(top: 8.0),
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => OrderDetail(
                              customerName: '${documentSnapshot["customer"]}',
                              dateOrder: '${documentSnapshot["dateOrder"]}',
                              datePlay: '${documentSnapshot["datePlay"]}',
                              dateTimePlayID: '${documentSnapshot["dateTimePlayID"]}',
                              note: '${documentSnapshot["note"]}',
                              orderId: '${documentSnapshot["orderID"]}',
                              orderStatus: '${documentSnapshot["orderStatus"]}',
                              phoneNo: '${documentSnapshot["phone"]}',
                              sanNo: '${documentSnapshot["sanNo"]}',
                              timeEnd: '${documentSnapshot["timeEnd"]}',
                              timeStart: '${documentSnapshot["timeStart"]}',
                              userManagement: '${documentSnapshot["userManagement"]}',
                              userOrder: '${documentSnapshot["userOrder"]}',
                            )));
                      },
                      child: Card(
                        margin: EdgeInsets.fromLTRB(16.0, 6.0, 16.0, 0.0),
                        child: ListTile(
                          isThreeLine: true,
                          //leading: Icon(Icons.info),
                          leading: CircleAvatar(
                            radius: 25.0,
                            backgroundColor: Colors.brown[100],
                          ),
                          title: Text('${documentSnapshot["timeStart"]} - ${documentSnapshot["timeEnd"]} (${DateFormat("dd/MM/yyyy").format(DateTime.parse(documentSnapshot["datePlay"]))})',
                            style: TextStyle(color: Colors.red[900], fontSize: 16.0),),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox(height: 8.0),
                              Text('dateTimePlayID: (${documentSnapshot["dateTimePlayID"]})',
                                style: TextStyle(color: Colors.black, fontSize: 12.0),
                              ),
                              Text('${documentSnapshot["customer"]}',
                                style: TextStyle(color: Colors.blue[900], fontSize: 18.0),
                              ),
                              SizedBox(height: 8.0),
                              Text('Điện thoại: ${documentSnapshot["phone"]}',
                                style: TextStyle(color: Colors.blue[900], fontSize: 16.0),
                              ),
                              SizedBox(height: 8.0),
                              Row(
                                children: <Widget>[
                                  Text('Đá sân ${documentSnapshot["sanNo"]}  -',
                                    style: TextStyle(color: Colors.blue[900], fontSize: 16.0),
                                  ),
                                  SizedBox(width: 8.0),
                                  Text('${documentSnapshot["orderStatus"]}',
                                    style: TextStyle(color: Colors.blue, fontSize: 16.0),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          //subtitle: Text(documentSnapshot["customer"]),
                          //trailing: ,
                        ),
                      ),
                    ),
                  );
                }
            );
          }else{
            return Align(
              alignment: FractionalOffset.center,
              child: Text("Loading..."),
            );
          }
        }
    );
  }

  // =============================================
  Widget tab3 (BuildContext context){
    return StreamBuilder(
        stream: Firestore.instance.collection("orders")
            .where('sanNo', isEqualTo: '3')
            .where('orderStatus', isEqualTo: 'Pending')
            .orderBy("dateTimePlayID")
            //.orderBy("timeStart")
            .snapshots(),
        builder: (context, snapshot) {
          if(snapshot.hasData) {
            return ListView.builder(
                itemCount: snapshot.data.documents.length,
                itemBuilder: (context, index){
                  DocumentSnapshot documentSnapshot = snapshot.data.documents[index];
                  return Padding(
                    padding: EdgeInsets.only(top: 8.0),
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => OrderDetail(
                              customerName: '${documentSnapshot["customer"]}',
                              dateOrder: '${documentSnapshot["dateOrder"]}',
                              datePlay: '${documentSnapshot["datePlay"]}',
                              dateTimePlayID: '${documentSnapshot["dateTimePlayID"]}',
                              note: '${documentSnapshot["note"]}',
                              orderId: '${documentSnapshot["orderID"]}',
                              orderStatus: '${documentSnapshot["orderStatus"]}',
                              phoneNo: '${documentSnapshot["phone"]}',
                              sanNo: '${documentSnapshot["sanNo"]}',
                              timeEnd: '${documentSnapshot["timeEnd"]}',
                              timeStart: '${documentSnapshot["timeStart"]}',
                              userManagement: '${documentSnapshot["userManagement"]}',
                              userOrder: '${documentSnapshot["userOrder"]}',
                            )));
                      },
                      child: Card(
                        margin: EdgeInsets.fromLTRB(16.0, 6.0, 16.0, 0.0),
                        child: ListTile(
                          isThreeLine: true,
                          //leading: Icon(Icons.info),
                          leading: CircleAvatar(
                            radius: 25.0,
                            backgroundColor: Colors.brown[100],
                          ),
                          title: Text('${documentSnapshot["timeStart"]} - ${documentSnapshot["timeEnd"]} (${DateFormat("dd/MM/yyyy").format(DateTime.parse(documentSnapshot["datePlay"]))})',
                            style: TextStyle(color: Colors.red[900], fontSize: 16.0),),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox(height: 8.0),
                              Text('dateTimePlayID: ${documentSnapshot["dateTimePlayID"]})',
                                style: TextStyle(color: Colors.black, fontSize: 12.0),
                              ),
                              Text('${documentSnapshot["customer"]}',
                                style: TextStyle(color: Colors.blue[900], fontSize: 18.0),
                              ),
                              SizedBox(height: 8.0),
                              Text('Điện thoại: ${documentSnapshot["phone"]}',
                                style: TextStyle(color: Colors.blue[900], fontSize: 16.0),
                              ),
                              SizedBox(height: 8.0),
                              Row(
                                children: <Widget>[
                                  Text('Đá sân ${documentSnapshot["sanNo"]}  -',
                                    style: TextStyle(color: Colors.blue[900], fontSize: 16.0),
                                  ),
                                  SizedBox(width: 8.0),
                                  Text('${documentSnapshot["orderStatus"]}',
                                    style: TextStyle(color: Colors.blue, fontSize: 16.0),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          //subtitle: Text(documentSnapshot["customer"]),
                          //trailing: ,
                        ),
                      ),
                    ),
                  );
                }
            );
          }else{
            return Align(
              alignment: FractionalOffset.center,
              child: Text("Loading..."),
            );
          }
        }
    );
  }

}
