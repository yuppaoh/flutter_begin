import 'package:appdemo/screens/layouts/order_detail.dart';
import 'package:appdemo/services/auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class OrderList extends StatefulWidget {
  @override
  _OrderListState createState() => _OrderListState();
}

class _OrderListState extends State<OrderList> {
  final AuthService _auth = AuthService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.brown[50],
        appBar: AppBar(
          title: Text('Danh sách đặt sân', style: TextStyle(color: Colors.yellow)),
          backgroundColor: Colors.green[400],
          elevation:  0.0,
          actions: <Widget>[

            FlatButton.icon(
              icon: Icon(Icons.person),
              label: Text('logout'),
              onPressed: () async {
                await _auth.signOut();
              },
            ),
          ],
        ),
        body: Center(
          child: _buildList(),

// =====StreamBuilder Start===================================================
/*
          child: StreamBuilder(
              stream: Firestore.instance.collection("orders").orderBy("orderID", descending: true).snapshots(),
              builder: (context, snapshot) {
                if(snapshot.hasData) {
                  return ListView.builder(
                    itemCount: snapshot.data.documents.length,
                    itemBuilder: (context, index){
                      DocumentSnapshot documentSnapshot = snapshot.data.documents[index];

                      //_buildList();

                      return Padding(
                        padding: EdgeInsets.only(top: 8.0),
                        child: InkWell(
                          onTap: () {
                            Navigator.of(context).push(
                                MaterialPageRoute(builder: (context) => OrderDetail(

//                                    assetPath: imgPath,
//                                    cookieprice: price,
//                                    cookiename: name
                                )));
                          },
                          child: Card(
                            margin: EdgeInsets.fromLTRB(16.0, 6.0, 16.0, 0.0),
                            child: ListTile(
                              isThreeLine: true,
                              //leading: Icon(Icons.info),
                              leading: CircleAvatar(
                                radius: 25.0,
                                backgroundColor: Colors.brown[100],
                              ),
                              title: Text('${documentSnapshot["timeStart"]} - ${documentSnapshot["timeEnd"]}'),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  SizedBox(height: 8.0),
                                  Text('Khach hang: ${documentSnapshot["customer"]}'),
                                  SizedBox(height: 8.0),
                                  Text('So dien thoai: ${documentSnapshot["phone"]}'),
                                  SizedBox(height: 8.0),
                                  Text('Status: ${documentSnapshot["orderState"]}'),
                                ],
                              ),
                              //subtitle: Text(documentSnapshot["customer"]),

                              //trailing: ,
                            ),
                          ),
                        ),
                      );
                    }
                  );
                }else{
                  return Align(
                    alignment: FractionalOffset.center,
                    child: Text("Loading info..."),
                  );
                }
              }
          )

 */
// =====StreamBuilder END===================================================

        )
    );
  }

  Widget _buildList() {
    return StreamBuilder(
        stream: Firestore.instance.collection("orders").orderBy("orderID").snapshots(),
        builder: (context, snapshot) {
          if(snapshot.hasData) {
            return ListView.builder(
                itemCount: snapshot.data.documents.length,
                itemBuilder: (context, index){
                  DocumentSnapshot documentSnapshot = snapshot.data.documents[index];
                  return Padding(
                    padding: EdgeInsets.only(top: 8.0),
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => OrderDetail(
                              customerName: '${documentSnapshot["customer"]}',
                              dateOrder: '${documentSnapshot["dateOrder"]}',
                              datePlay: '${documentSnapshot["datePlay"]}',
                              dateTimePlayID: '${documentSnapshot["dateTimePlayID"]}',
                              note: '${documentSnapshot["note"]}',
                              orderId: '${documentSnapshot["orderID"]}',
                              orderStatus: '${documentSnapshot["orderStatus"]}',
                              phoneNo: '${documentSnapshot["phone"]}',
                              sanNo: '${documentSnapshot["sanNo"]}',
                              timeEnd: '${documentSnapshot["timeEnd"]}',
                              timeStart: '${documentSnapshot["timeStart"]}',
                              userManagement: '${documentSnapshot["userManagement"]}',
                              userOrder: '${documentSnapshot["userOrder"]}',
                            )));
                      },
                      child: Card(
                        margin: EdgeInsets.fromLTRB(16.0, 6.0, 16.0, 0.0),
                        child: ListTile(
                          isThreeLine: true,
                          //leading: Icon(Icons.info),
                          leading: CircleAvatar(
                            radius: 25.0,
                            backgroundColor: Colors.brown[100],
//                            backgroundImage: ,
                          ),
                          title: Text('${documentSnapshot["timeStart"]} - ${documentSnapshot["timeEnd"]} (${DateFormat("dd/MM/yyyy").format(DateTime.parse(documentSnapshot["datePlay"]))})',
                            style: TextStyle(color: Colors.red[900], fontSize: 16.0),),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox(height: 8.0),
                              Text('orderID: (${documentSnapshot["orderID"]})',
                                style: TextStyle(color: Colors.black, fontSize: 12.0),
                              ),
                              Text('${documentSnapshot["customer"]}',
                                style: TextStyle(color: Colors.blue[900], fontSize: 18.0),
                              ),
                              SizedBox(height: 8.0),
                              Text('Điện thoại: ${documentSnapshot["phone"]}',
                                style: TextStyle(color: Colors.blue[900], fontSize: 16.0),
                              ),
                              SizedBox(height: 8.0),
                              Row(
                                children: <Widget>[
                                  Text('Đá sân ${documentSnapshot["sanNo"]}  -',
                                    style: TextStyle(color: Colors.blue[900], fontSize: 16.0),
                                  ),
                                  SizedBox(width: 8.0),
                                  Text('${documentSnapshot["orderStatus"]}',
                                    style: TextStyle(color: Colors.blue, fontSize: 16.0),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          //subtitle: Text(documentSnapshot["customer"]),

                          //trailing: ,
                        ),
                      ),
                    ),
                  );
                }
            );
          }else{
            return Align(
              alignment: FractionalOffset.center,
              child: Text("Loading info..."),
            );
          }
        }
    );
  }
}
