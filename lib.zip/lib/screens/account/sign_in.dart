import 'package:appdemo/screens/account/auth_user.dart';
import 'package:appdemo/screens/layouts/index.dart';
import 'package:appdemo/services/auth.dart';
import 'package:appdemo/shared/constants.dart';
import 'package:appdemo/shared/loading.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class SignIn extends StatefulWidget {

  final Function toggleView;
  SignIn({this.toggleView});

  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  final AuthService _auth = AuthService();
  final _formKey = GlobalKey<FormState>();
  bool loading = false;

  // Text field state
  String userName;
  String userPassword;
  String instantName, instantPassword, instantRole;
  
  bool flagUser = false;
  final firestoreInstance = Firestore.instance;
  bool _loginUser() {
    firestoreInstance
        .collection("users")
        .where('username', isEqualTo: userName)
        .where('password', isEqualTo: userPassword)
        .getDocuments()
        .then((value) {
      value.documents.forEach((result) {
        print('==================================');
        print('result.data: ${result.data}');
        print('result.data.keys: ${result.data.keys}');
        print('result.data.values: ${result.data.values}');
        print('username: ${result.data["username"]}');
        print('password: ${result.data["password"]}');
        print('role: ${result.data["role"]}');

        if(result.data["username"] == userName){instantName = userName;}
        if(result.data["password"] == userPassword){instantPassword = userPassword;}
        instantRole = result.data["role"];
      });
    });
    if(instantName == userName && instantPassword == userPassword){
      flagUser = true;
    }
    print('login: $flagUser');
    return flagUser;
  }


  @override
  Widget build(BuildContext context) {
    return loading ? Loading() : Scaffold(
      resizeToAvoidBottomPadding: false,
      backgroundColor: Colors.brown[100],
      appBar: AppBar(
        backgroundColor: Colors.brown[400],
        title: Text('Sign in with Account'),
        actions: <Widget>[
          FlatButton.icon(
              icon: Icon(Icons.person),
              label: Text('Register'),
              onPressed: () {
                widget.toggleView();
              }
          )
        ],
      ),

      body: Container(
        padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 50.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: <Widget>[
              SizedBox(height: 20.0),
              TextFormField(
                  validator: (val) => val.isEmpty ? 'Enter an username' : null,
                  decoration: textInputDecoration.copyWith(hintText: 'Username'),
                  onChanged: (val) {
                    setState(() => userName = val);
                  }
              ),
              SizedBox(height: 20.0),
              TextFormField(
                  obscureText: true,
                  validator: (val) => val.length < 6 ? 'Enter a password 6+ chars long' : null,
                  decoration: textInputDecoration.copyWith(hintText: 'password'),
                  onChanged: (val) {
                    setState(() => userPassword = val);
                  }
              ),

              SizedBox(height: 20.0),
              RaisedButton(
                padding: EdgeInsets.symmetric(vertical: 15.0, horizontal: 30.0),
                color: Colors.green[800],
                child: Text(
                  'Sign in',
                  style: TextStyle(color: Colors.yellow[300]),
                ),
                onPressed: () async{
                  if(_formKey.currentState.validate()){
                    print('username: $userName');
                    print('userPassword: $userPassword');
                    _loginUser();
                    if(flagUser == true){
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) => Index(
//                                userName: userName,
//                                passWord: userPassword,
//                                userRole: instantRole,
                              )
                          )
                      );
                    }
                    if(flagUser == false){
                      showDialog(
                        context: context,
                        builder: (_) => AlertDialog(
                          title: Text(
                            'Đăng nhập thất bại, vui lòng kiểm tra lại!',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.red, fontStyle: FontStyle.italic, fontSize: 16.0,
                            ),
                          ),
                          )
                      );
                    }
                  }
                },
              ),
              SizedBox(height: 20.0),
//              Text(
//              userName != null ? userName : 'null'
//              ),
            ],
          ),
        ),
      ),
    );
  }
}
