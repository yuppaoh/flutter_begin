import 'package:appdemo/models/thufc.dart';
import 'package:appdemo/screens/home/settings_form.dart';
import 'package:appdemo/screens/layouts/product.dart';
import 'package:appdemo/screens/home/thufc_list.dart';
import 'package:appdemo/services/auth.dart';
import 'package:appdemo/shared/constants.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:appdemo/services/database.dart';
import 'package:provider/provider.dart';

class Home extends StatelessWidget {
  final AuthService _auth = AuthService();

  int _currentIndex = 0;
  final tab1 = ['Home page','Products page','Message page','History page','Profile page'];
  final tab = [
    Center(child: Text('Home page')),
    Center(child: Product()),
//    Center(child: Text('Products page')),
    Center(child: Text('Message page')),
    Center(child: Text('History page')),
    Center(child: Text('Profile page'))
  ];

  @override
  Widget build(BuildContext context) {

    void _showSettingPanel() {
      showModalBottomSheet(context: context, builder: (context){
        return Container(
          padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 60.0),
          child: SettingsForm(),
        );
      });
    }

    return StreamProvider<List<Thufc>>.value(
      value: DatabaseService().thufcs,
      child: Scaffold(
        backgroundColor: Colors.brown[50],
        appBar: AppBar(
          title: Text('Home page',
          style: TextStyle(color: Colors.yellow)),
          backgroundColor: Colors.green[400],
          elevation:  0.0,
          actions: <Widget>[
            FlatButton.icon(
              icon: Icon(Icons.person),
              label: Text('logout'),
              onPressed: () async {
                await _auth.signOut();
              },
            ),
            FlatButton.icon(
              icon: Icon(Icons.settings),
              label: Text('setting'),
              onPressed: () => _showSettingPanel(),
            ),
          ],
        ),
        body: ThufcList(),

        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.white70,
          currentIndex: _currentIndex,
          type: BottomNavigationBarType.fixed,
          items: [
            BottomNavigationBarItem(
                icon: Icon(Icons.home),
                title: Text('Home'),
                backgroundColor: Colors.blue
            ),
            BottomNavigationBarItem(
                icon: Icon(Icons.shop),
                title: Text('Product'),
                backgroundColor: Colors.red
            ),
            BottomNavigationBarItem(
                icon: Icon(Icons.message),
                title: Text('Message'),
                backgroundColor: Colors.green
            ),
            BottomNavigationBarItem(
                icon: Icon(Icons.history),
                title: Text('History'),
                backgroundColor: Colors.yellow
            ),
            BottomNavigationBarItem(
                icon: Icon(Icons.person),
                title: Text('Profile'),
                backgroundColor: Colors.lightGreenAccent
            ),
          ],
          onTap: (index) async {
            if(index == 1){
              dynamic result = Product();
//              Navigator.of(context).push(MaterialPageRoute(builder: (context) => Product()));
            }
          }
        )
      ),
    );
  }
}
