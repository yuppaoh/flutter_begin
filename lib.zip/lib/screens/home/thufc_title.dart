import 'package:appdemo/models/thufc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ThufcTitle extends StatelessWidget {

  final Thufc thufc;
  ThufcTitle({this.thufc});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 8.0),
      child: Card(
        margin: EdgeInsets.fromLTRB(16.0, 6.0, 16.0, 0.0),
        child: ListTile(
          leading: CircleAvatar(
            radius: 25.0,
            backgroundColor: Colors.brown[thufc.strength],
          ),
          title: Text(thufc.name),
          subtitle: Text('Takes ${thufc.sugars} sugar(s)'),
        ),
      ),
    );
  }
}
