import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:appdemo/models/thufc.dart';
import 'package:appdemo/screens/home/thufc_title.dart';

class ThufcList extends StatefulWidget {
  @override
  _ThufcListState createState() => _ThufcListState();
}

class _ThufcListState extends State<ThufcList> {
  @override
  Widget build(BuildContext context) {

    final thufcs = Provider.of<List<Thufc>>(context);

    return ListView.builder(
      itemCount: thufcs.length,
      itemBuilder: (context, index){
        return ThufcTitle(thufc: thufcs[index]);
      },
    );

    return Container();
  }
}
