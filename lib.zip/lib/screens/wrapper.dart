import 'package:appdemo/screens/account/sign_in.dart';
import 'package:appdemo/screens/authenticate/authenticate.dart';
import 'package:appdemo/screens/home/home.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:appdemo/models/user.dart';
import 'package:appdemo/screens/account/sign_in.dart';

import 'layouts/index.dart';

class Wrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    final user = Provider.of<User>(context);
    print(user);

//    return Index();

    if(user == null){
//      return Authenticate();
      return SignIn();

    }else{
//      return Home();
      return Index();

    }

  }
}
