import 'package:appdemo/models/order.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:appdemo/models/thufc.dart';

class DatabaseService {
  final String uid;
  DatabaseService({this.uid});

  final CollectionReference fcCollection = Firestore.instance.collection('thufcs');
  final CollectionReference orderCollection = Firestore.instance.collection('orders');

  Future updateUserData(String sugars, String name, int strength) async {
    return await fcCollection.document(uid).setData({
      'sugars': sugars,
      'name': name,
      'strength': strength,
    });
  }

  // thufc list from snapshot
  List<Thufc> _thufcListFromSnapshot(QuerySnapshot snapshot){
    return snapshot.documents.map((doc) {
      return Thufc(
        name: doc.data['name'] ?? '',
        strength: doc.data['strength'] ?? 0,
        sugars: doc.data['sugars'] ?? '0'
      );
    }).toList();
  }

  // get thufcs stream
  Stream<List<Thufc>> get thufcs {
    return fcCollection.snapshots().map(_thufcListFromSnapshot);
  }


  Future updateOrderData(String id, String customer, int phone) async {
    //String timeStart, String timeEnd, String note, DateTime dateOrder, DateTime datePlay
    return await fcCollection.document(uid).setData({
      'id': id,
      'customer': customer,
      'phone': phone,
//      'timeStart': timeStart,
//      'timeEnd': timeEnd,
//      'note': note,
//      'dateOrder': dateOrder,
//      'datePlay': datePlay
    });
  }

  // order list from snapshot
  List<Orders> _orderListFromSnapshot(QuerySnapshot snapshot){
    return snapshot.documents.map((doc) {
      return Orders(
          id: doc.data['id'] ?? '0',
          customer: doc.data['customer'] ?? '',
          phone: doc.data['phone'] ?? '',
//          timeStart: doc.data['timeStart'] ?? '',
//          timeEnd: doc.data['timeEnd'] ?? '',
//          note: doc.data['note'] ?? '',
//          dateOrder: doc.data['dateOrder'] ?? '',
//          datePlay: doc.data['datePlay'] ?? '',
      );
    }).toList();
  }

  // get orders stream
  Stream<List<Orders>> get orders {
    return orderCollection.snapshots().map(_orderListFromSnapshot);
  }
}